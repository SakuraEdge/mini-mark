/**
 * N-ary operator → `m:nary` (ECMA-376 §7.1.2.70).
 * `m:limLoc` ∈ ST_LimLoc §7.1.3.8 (`subSup` | `undOvr`).
 * `m:grow` / `m:subHide` / `m:supHide` ∈ ST_OnOff §7.1.3.9 (`on` | `off`).
 */
import { getTextContent } from '../helpers.js'

const NARY_REGEXP = /^[\u220f-\u2211]|[\u2229-\u2233]|[\u22c0-\u22c3]$/
const GROW_REGEXP = /^\u220f|\u2211|[\u2229-\u222b]|\u222e|\u222f|\u2232|\u2233|[\u22c0-\u22c3]$/

/**
 * If `parent`'s last child is `m:nary`, return its base `m:e` (§7.1.2.32).
 * Following siblings of an n-ary operator are the operand, not mixed content
 * on `m:oMath` / `m:e` (CT_OMathArg = `argPr` + EG_OMathElements + `ctrlPr`).
 */
export function naryBaseArg(parent) {
  const children = parent?.children
  if (!children?.length) return null
  const last = children[children.length - 1]
  if (last?.name !== 'm:nary') return null
  return last.children[last.children.length - 1] || null
}

export function getNary(node) {
  // Check if node contains only a nary operator.
  const text = getTextContent(node)
  if (NARY_REGEXP.test(text)) {
    return text
  }
  return false
}

export function getNaryTarget(naryChar, element, type, subHide = false, supHide = false) {
  const stretchy = element.attribs?.stretchy
  const grow =
    stretchy === 'true'
      ? 'on'
      : stretchy === 'false'
        ? 'off'
        : GROW_REGEXP.test(naryChar)
          ? 'on'
          : 'off'
  return {
    type: 'tag',
    name: 'm:nary',
    attribs: {},
    children: [
      {
        type: 'tag',
        name: 'm:naryPr',
        attribs: {},
        children: [
          { type: 'tag', name: 'm:chr', attribs: { 'm:val': naryChar }, children: [] },
          { type: 'tag', name: 'm:limLoc', attribs: { 'm:val': type }, children: [] },
          { type: 'tag', name: 'm:grow', attribs: { 'm:val': grow }, children: [] },
          {
            type: 'tag',
            name: 'm:subHide',
            attribs: { 'm:val': subHide ? 'on' : 'off' },
            children: []
          },
          {
            type: 'tag',
            name: 'm:supHide',
            attribs: { 'm:val': supHide ? 'on' : 'off' },
            children: []
          }
        ]
      }
    ]
  }
}
